/**
 * mail.js — Mail activity module
 * Handles compose form, calls /api/mail, updates activity log + visualizer.
 */

(function () {
  'use strict';

  const API_BASE = '';

  function getEl(id) { return document.getElementById(id); }

  function logLine(text, type = 'info') {
    const el = getEl('mail-log-content');
    if (!el) return;
    const color = type === 'success' ? 'var(--green)'
                : type === 'error'   ? 'var(--red)'
                : type === 'cmd'     ? 'var(--cyan)'
                : 'var(--text-secondary)';
    const time = new Date().toLocaleTimeString();
    el.innerHTML += `<div style="color:${color};margin:2px 0;">[${time}] ${text}</div>`;
    el.scrollTop = el.scrollHeight;
  }

  function clearLog() {
    const el = getEl('mail-log-content');
    if (el) el.innerHTML = '';
  }

  function setStatus(text) {
    const el = getEl('mail-send-status');
    if (el) el.textContent = text;
  }

  const mailModule = {
    async send() {
      const toEl      = getEl('mail-to');
      const subjEl    = getEl('mail-subject');
      const bodyEl    = getEl('mail-body');
      const sendBtn   = getEl('btn-send');

      const to      = toEl?.value?.trim()   || '';
      const subject = subjEl?.value?.trim() || '';
      const body    = bodyEl?.value?.trim() || '';

      // Validate
      if (!to || !to.includes('@')) {
        window.app.toast('Please enter a valid recipient email', 'error');
        toEl?.focus();
        return;
      }
      if (!subject) {
        window.app.toast('Subject cannot be empty', 'error');
        subjEl?.focus();
        return;
      }
      if (!body) {
        window.app.toast('Body cannot be empty', 'error');
        bodyEl?.focus();
        return;
      }

      if (sendBtn) sendBtn.disabled = true;
      clearLog();
      setStatus('📤 Sending…');

      logLine(`Initiating SMTP session for → ${to}`, 'info');
      logLine(`Subject: ${subject}`, 'info');
      logLine('Performing DNS MX lookup for recipient domain…', 'cmd');

      window.visualizer.showLoading('DNS MX lookup + SMTP handshake in progress…');

      try {
        const res = await fetch(`${API_BASE}/api/mail`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ to, subject, body }),
        });

        if (!res.ok) {
          throw new Error(`Server error: ${res.status} ${res.statusText}`);
        }

        const data = await res.json();

        if (data.success) {
          setStatus('✅ Sent!');
          logLine(`✓ Email delivered to ${to}`, 'success');
          logLine(`Total protocol steps captured: ${data.steps?.length || 0}`, 'info');
          window.app.toast(`Email sent to ${to}!`, 'success');
        } else {
          setStatus('❌ Failed');
          logLine(`✗ Send failed: ${data.error || 'Unknown error'}`, 'error');
          if (data.error?.includes('.env')) {
            logLine('ℹ️  Tip: Copy .env.example → .env and fill in your Gmail App Password', 'info');
          }
          window.app.toast(data.error || 'Send failed', 'error');
        }

        // Load SMTP steps into visualizer regardless of success/failure
        if (data.steps && data.steps.length > 0) {
          window.visualizer.loadSteps(data.steps);
        }

      } catch (err) {
        setStatus('❌ Error');
        logLine(`Error: ${err.message}`, 'error');
        window.visualizer.showError(`Failed: ${err.message}`);
        window.app.toast(err.message, 'error');
      } finally {
        if (sendBtn) sendBtn.disabled = false;
        setTimeout(() => setStatus(''), 5000);
      }
    },
  };

  window.mailModule = mailModule;
})();
