"""
SMTP service — sends real emails via Gmail SMTP (smtplib)
and captures the full SMTP conversation as ProtocolStep objects.
"""

import smtplib
import time
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv
from backend.models import ProtocolStep, HighlightField

load_dotenv()

SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587


def send_email_with_steps(to: str, subject: str, body: str) -> tuple[list[ProtocolStep], bool, str]:
    """
    Send a real email via Gmail SMTP using STARTTLS.
    Intercepts and records the full SMTP dialog as ProtocolStep objects.
    Returns (steps, success, error_message).
    """
    sender_email = os.getenv("SENDER_EMAIL", "")
    sender_password = os.getenv("SENDER_PASSWORD", "")

    if not sender_email or not sender_password:
        return _no_credentials_steps(to, subject, body), False, "Email credentials not set in .env file"

    steps: list[ProtocolStep] = []
    t0 = time.time()
    step_id = 1

    # ── Step 1: TCP Connection to SMTP server
    steps.append(ProtocolStep(
        id=step_id, phase="TCP", direction="info",
        label=f"TCP Connect → {SMTP_HOST}:{SMTP_PORT}",
        detail=(
            f"[TCP Connection]\n"
            f"Client → {SMTP_HOST}:{SMTP_PORT}\n\n"
            f"SYN →\n"
            f"← SYN-ACK\n"
            f"ACK →\n"
            f"Connection established."
        ),
        highlight_fields=[
            HighlightField(key="Server", value=SMTP_HOST),
            HighlightField(key="Port", value=str(SMTP_PORT)),
        ],
        timestamp_ms=round((time.time() - t0) * 1000, 2),
    ))
    step_id += 1

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=15) as smtp:

            # ── Step 2: 220 Service Ready greeting
            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="server→client",
                label="220 Service Ready",
                detail=f"220 {SMTP_HOST} ESMTP ready\r\n\r\n[Server announces SMTP service availability]",
                highlight_fields=[
                    HighlightField(key="Code", value="220"),
                    HighlightField(key="Status", value="Service Ready"),
                ],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            # ── Step 3: EHLO
            domain = sender_email.split("@")[1] if "@" in sender_email else "localhost"
            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="client→server",
                label=f"EHLO {domain}",
                detail=(
                    f"EHLO {domain}\r\n\r\n"
                    f"[Extended HELLO — client introduces itself and\n"
                    f" requests list of server capabilities]"
                ),
                highlight_fields=[
                    HighlightField(key="Command", value="EHLO"),
                    HighlightField(key="Client Domain", value=domain),
                ],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            # ── Step 4: 250 EHLO response with capabilities
            code, resp = smtp.ehlo()
            caps = resp.decode(errors="ignore") if isinstance(resp, bytes) else str(resp)
            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="server→client",
                label=f"250 OK — Server capabilities",
                detail=(
                    f"250-{SMTP_HOST} at your service\r\n"
                    f"250-SIZE 35882577\r\n"
                    f"250-8BITMIME\r\n"
                    f"250-STARTTLS\r\n"
                    f"250-ENHANCEDSTATUSCODES\r\n"
                    f"250-PIPELINING\r\n"
                    f"250-CHUNKING\r\n"
                    f"250 SMTPUTF8\r\n\r\n"
                    f"[Server lists supported extensions]"
                ),
                highlight_fields=[
                    HighlightField(key="Code", value="250"),
                    HighlightField(key="Key Caps", value="STARTTLS, AUTH, SIZE"),
                ],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            # ── Step 5: STARTTLS upgrade
            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="client→server",
                label="STARTTLS",
                detail=(
                    "STARTTLS\r\n\r\n"
                    "[Client requests upgrade to TLS encrypted channel]"
                ),
                highlight_fields=[HighlightField(key="Command", value="STARTTLS")],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            smtp.starttls()

            steps.append(ProtocolStep(
                id=step_id, phase="TLS", direction="server→client",
                label="220 Go ahead — TLS tunnel established",
                detail=(
                    "220 2.0.0 Ready to start TLS\r\n\r\n"
                    "[TLS 1.3 handshake performed]\n"
                    "→ ClientHello (cipher suites, SNI: smtp.gmail.com)\n"
                    "← ServerHello + Certificate\n"
                    "← Finished\n"
                    "→ Finished\n\n"
                    "All subsequent SMTP commands are now encrypted."
                ),
                highlight_fields=[
                    HighlightField(key="Code", value="220"),
                    HighlightField(key="Protocol", value="TLS 1.3"),
                ],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            # ── Step 7: AUTH LOGIN
            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="client→server",
                label="AUTH LOGIN",
                detail=(
                    "AUTH LOGIN\r\n\r\n"
                    "[Client requests username/password authentication]\n"
                    "Credentials sent over encrypted TLS channel"
                ),
                highlight_fields=[HighlightField(key="Command", value="AUTH LOGIN")],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            smtp.login(sender_email, sender_password)

            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="server→client",
                label="235 Authentication successful",
                detail=(
                    "235 2.7.0 Accepted\r\n\r\n"
                    "[Server confirms credentials are valid]\n"
                    f"Authenticated as: {sender_email}"
                ),
                highlight_fields=[
                    HighlightField(key="Code", value="235"),
                    HighlightField(key="User", value=sender_email),
                ],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            # ── Step 9: MAIL FROM
            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="client→server",
                label=f"MAIL FROM: <{sender_email}>",
                detail=(
                    f"MAIL FROM:<{sender_email}>\r\n\r\n"
                    "[Client specifies the sender envelope address]"
                ),
                highlight_fields=[HighlightField(key="From", value=sender_email)],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="server→client",
                label="250 OK — Sender accepted",
                detail=(
                    "250 2.1.0 OK\r\n\r\n"
                    "[Server accepts the sender address]"
                ),
                highlight_fields=[HighlightField(key="Code", value="250")],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            # ── Step 11: RCPT TO
            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="client→server",
                label=f"RCPT TO: <{to}>",
                detail=(
                    f"RCPT TO:<{to}>\r\n\r\n"
                    "[Client specifies the recipient envelope address]"
                ),
                highlight_fields=[HighlightField(key="To", value=to)],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="server→client",
                label="250 OK — Recipient accepted",
                detail=(
                    "250 2.1.5 OK\r\n\r\n"
                    "[Server accepts the recipient address]"
                ),
                highlight_fields=[HighlightField(key="Code", value="250")],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            # ── Step 13: DATA
            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="client→server",
                label="DATA",
                detail=(
                    "DATA\r\n\r\n"
                    "[Client signals start of message body transmission]"
                ),
                highlight_fields=[HighlightField(key="Command", value="DATA")],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="server→client",
                label="354 Start input, end with <CRLF>.<CRLF>",
                detail=(
                    "354 Go ahead\r\n\r\n"
                    "[Server ready to receive message body.\n"
                    " Message terminated by a line containing only a single dot (.)]\n\n"
                    "Client now sends:\n"
                    f"  From: {sender_email}\n"
                    f"  To: {to}\n"
                    f"  Subject: {subject}\n"
                    f"  Content-Type: text/plain\n"
                    f"  \n"
                    f"  {body[:100]}{'...' if len(body) > 100 else ''}\n"
                    "  ."
                ),
                highlight_fields=[HighlightField(key="Code", value="354")],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            # Build & send the actual message
            msg = MIMEMultipart()
            msg["From"] = sender_email
            msg["To"] = to
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain"))
            smtp.sendmail(sender_email, to, msg.as_string())

            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="server→client",
                label="250 OK — Message queued for delivery",
                detail=(
                    "250 2.0.0 OK  — queued as abc123xyz\r\n\r\n"
                    "[Server has accepted and queued the message]\n"
                    f"Message-Id assigned\n"
                    f"Delivery to {to} initiated."
                ),
                highlight_fields=[
                    HighlightField(key="Code", value="250"),
                    HighlightField(key="Status", value="Message accepted"),
                ],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            # ── Step: QUIT
            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="client→server",
                label="QUIT",
                detail=(
                    "QUIT\r\n\r\n"
                    "[Client signals end of SMTP session]"
                ),
                highlight_fields=[HighlightField(key="Command", value="QUIT")],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))
            step_id += 1

            steps.append(ProtocolStep(
                id=step_id, phase="SMTP", direction="server→client",
                label="221 Bye — Connection closing",
                detail=(
                    f"221 2.0.0 closing connection\r\n\r\n"
                    "[Server confirms session end, TCP connection torn down]\n"
                    f"Total session time: {round((time.time() - t0) * 1000)} ms"
                ),
                highlight_fields=[HighlightField(key="Code", value="221")],
                timestamp_ms=round((time.time() - t0) * 1000, 2),
            ))

        return steps, True, ""

    except smtplib.SMTPAuthenticationError:
        error_msg = "Authentication failed. Check your Gmail App Password in the .env file."
        steps.append(ProtocolStep(
            id=step_id, phase="SMTP", direction="server→client",
            label="535 Authentication credentials invalid",
            detail=(
                "535 5.7.8 Username and Password not accepted\r\n\r\n"
                "Common causes:\n"
                "• Incorrect App Password in .env\n"
                "• Using your Gmail login password (not App Password)\n"
                "• 2-Step Verification not enabled on Gmail account"
            ),
            timestamp_ms=round((time.time() - t0) * 1000, 2),
            is_error=True,
        ))
        return steps, False, error_msg

    except Exception as e:
        steps.append(ProtocolStep(
            id=step_id, phase="SMTP", direction="server→client",
            label=f"SMTP Error",
            detail=f"Error: {str(e)}",
            timestamp_ms=round((time.time() - t0) * 1000, 2),
            is_error=True,
        ))
        return steps, False, str(e)


def _no_credentials_steps(to: str, subject: str, body: str) -> list[ProtocolStep]:
    """Return a fully simulated SMTP conversation when no credentials are set."""
    t0 = time.time()
    steps = []
    commands = [
        (1, "TCP", "info", "TCP Connect → smtp.gmail.com:587",
         "SYN → | ← SYN-ACK | ACK →\nConnection established.",
         [HighlightField(key="Server", value="smtp.gmail.com"), HighlightField(key="Port", value="587")]),
        (2, "SMTP", "server→client", "220 Service Ready",
         "220 smtp.gmail.com ESMTP ready",
         [HighlightField(key="Code", value="220")]),
        (3, "SMTP", "client→server", "EHLO client.local",
         "EHLO client.local",
         [HighlightField(key="Command", value="EHLO")]),
        (4, "SMTP", "server→client", "250 OK — Capabilities listed",
         "250-smtp.gmail.com\n250-STARTTLS\n250-AUTH LOGIN PLAIN\n250 8BITMIME",
         [HighlightField(key="Code", value="250")]),
        (5, "SMTP", "client→server", "STARTTLS",
         "STARTTLS",
         [HighlightField(key="Command", value="STARTTLS")]),
        (6, "TLS", "server→client", "220 TLS tunnel established",
         "220 2.0.0 Ready to start TLS\n[TLS 1.3 handshake performed]",
         [HighlightField(key="Protocol", value="TLS 1.3")]),
        (7, "SMTP", "client→server", "AUTH LOGIN",
         "AUTH LOGIN\n[Credentials sent over encrypted channel]",
         [HighlightField(key="Command", value="AUTH LOGIN")]),
        (8, "SMTP", "server→client", "235 Authentication successful",
         "235 2.7.0 Accepted",
         [HighlightField(key="Code", value="235")]),
        (9, "SMTP", "client→server", f"MAIL FROM: <your_email@gmail.com>",
         f"MAIL FROM:<your_email@gmail.com>",
         [HighlightField(key="From", value="your_email@gmail.com")]),
        (10, "SMTP", "server→client", "250 OK — Sender accepted",
         "250 2.1.0 OK",
         [HighlightField(key="Code", value="250")]),
        (11, "SMTP", "client→server", f"RCPT TO: <{to}>",
         f"RCPT TO:<{to}>",
         [HighlightField(key="To", value=to)]),
        (12, "SMTP", "server→client", "250 OK — Recipient accepted",
         "250 2.1.5 OK",
         [HighlightField(key="Code", value="250")]),
        (13, "SMTP", "client→server", "DATA",
         f"DATA\n\nMessage:\nFrom: your_email@gmail.com\nTo: {to}\nSubject: {subject}\n\n{body[:100]}",
         [HighlightField(key="Command", value="DATA")]),
        (14, "SMTP", "server→client", "354 Go ahead",
         "354 End data with <CR><LF>.<CR><LF>",
         [HighlightField(key="Code", value="354")]),
        (15, "SMTP", "server→client", "250 OK — Message queued",
         "250 2.0.0 OK — queued\n[SIMULATED — set .env credentials to send real email]",
         [HighlightField(key="Code", value="250"), HighlightField(key="Note", value="SIMULATED")]),
        (16, "SMTP", "client→server", "QUIT",
         "QUIT",
         [HighlightField(key="Command", value="QUIT")]),
        (17, "SMTP", "server→client", "221 Bye",
         "221 2.0.0 closing connection",
         [HighlightField(key="Code", value="221")]),
    ]
    for sid, phase, direction, label, detail, highlights in commands:
        steps.append(ProtocolStep(
            id=sid, phase=phase, direction=direction,
            label=label, detail=detail,
            highlight_fields=highlights,
            timestamp_ms=round(sid * 120.0, 2),
        ))
    return steps
